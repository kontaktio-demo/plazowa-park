# Mapa treści: co znika i gdzie ta sama informacja zostaje

Kontrola, żeby nic się nie zgubiło. Każda wycinana informacja ma wskazane miejsce, w którym zostaje.

| Co wycinamy | Gdzie ta sama informacja zostaje |
|---|---|
| Karty 6 budynków (sekcja Osiedle) | Interaktywny plan + tabela (kolumna Budynek) |
| Akapit "Osiedle to 16 mieszkań i 4 domy w 10 budynkach..." | Skrócony do 2 zdań jako lead sekcji Mieszkania i domy |
| Filtr budynków (7 chipów) | Interaktywny plan osiedla |
| Sortowanie: metraż rosnąco, cena malejąco | Cena rosnąco + metraż malejąco |
| Sekcja Cennik jako osobna sekcja | Ta sama tabela wewnątrz sekcji Mieszkania i domy |
| Siatka 6 kart + "Pokaż wszystkie 20" | Pełna tabela (desktop) / karty (mobile) |
| Sekcja Życie: Kameralne osiedle | Hero: "Kameralne osiedle... 16 mieszkań i 4 domy" |
| Sekcja Życie: Las i woda za progiem | Sekcja Okolica + /lokalizacja |
| Sekcja Życie: Przestrzeń dla dzieci | Sekcja Standard, kafelek "Prywatny ogród i taras" |
| Standard: kafelek Rekuperacja | Linijka "Za dopłatą: rekuperacja, fotowoltaika, wykończenie pod klucz" |
| Standard: kafelek Fotowoltaika | jw. |
| Standard: kafelek Wykończenie pod klucz | jw. |
| Standard: kafelek Materiały premium | Akapit wiodący sekcji Standard (elewacja) |
| Standard: kafelek Prywatne wejście | Akapit wiodący sekcji Standard |
| Standard: 2 z 3 akapitów opisowych | Jeden akapit + 6 kafelków |
| Okolica: lista 6 atrakcji na stronie głównej | `/lokalizacja` (identyczna lista, pełne opisy) |
| Okolica: przełącznik mapy satelitarnej ALBO mapa 3D | Zostaje jedno, drugie na `/lokalizacja` |
| Deweloper: blok Dane rejestrowe (KRS/NIP/REGON/VAT/kapitał) | Stopka (komplet tych samych danych) |
| Jak przebiega zakup: 5 kroków | 3 kroki + zdanie o rachunku powierniczym i prospekcie |
| FAQ: Ile mieszkań i domów liczy osiedle | Hero + lead sekcji Mieszkania i domy |
| FAQ: Gdzie dokładnie leży osiedle | Sekcja Okolica + stopka + `/lokalizacja` |
| FAQ: Jak daleko do Łodzi, Strykowa, Warszawy | Sekcja Okolica (4 dystanse) + `/lokalizacja` |
| FAQ: Co znajduje się w okolicy | `/lokalizacja` |
| FAQ: Jaki jest standard i technologia | Sekcja Standard |
| Podstrona lokalu: blok "O mieszkaniu X" (4 akapity) | Sekcja Standard i Okolica na stronie głównej, `/lokalizacja` |
| Podstrona lokalu: akapit podsumowujący parametry | Tabela parametrów tuż obok |
| Podstrona lokalu: sekcja Lokalizacja z mapą | Jedna linijka z linkiem do `/lokalizacja` |

## Nie ruszamy

Ceny, metraże, powierzchnie ogrodów, statusy, liczba pokoi i kondygnacji, wykaz pomieszczeń na rzutach, dane rejestrowe w stopce, telefon, mail, adres, nota prawna art. 66 KC, partnerzy i rabat CBG, prefill `?lokal=`, spacer 360, strony prawne, CSV, wszystkie 25 URL-i.
