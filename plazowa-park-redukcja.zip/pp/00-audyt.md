# Plażowa Park - audyt architektury i redukcji

Data: 19.09.2026 · zakres: plazowa-park.pl (produkcja) · cel: mniej ścieżek, mniej powtórzeń, ta sama treść powiedziana raz

---

## 1. Co faktycznie jest na stronie (stan zmierzony)

**URL-e: 25**
- 1 strona główna
- 20 podstron lokali `/mieszkania-i-domy/{id}`
- 1 `/lokalizacja`
- 3 prawne (polityka prywatności, cookies, regulamin)
- plus `/ceny-ofertowe.csv`

**Strona główna:**
| metryka | wartość |
|---|---|
| sekcje | 11 |
| słowa | 2 769 |
| linki | 83 |
| przyciski / kontrolki | 96 |
| unikalne warianty obrazów (next/image) | 162 |
| HTML | 301 KB |
| JS (transfer, 10 plików) | 715 KB |
| hero.webp @2400 q80 | 448 KB |

Rozbicie kontrolek: sekcja `#mieszkania-i-domy` = 46 przycisków (plan + filtry + sortowanie), `#cennik` = 20, `#faq` = 11, `#okolica` = 8, `#osiedle` = 6.

**Podstrona lokalu:** ok. 4 500 znaków tekstu, z czego ~1 800 to opisowy blok "O mieszkaniu X" powtarzany w 20 wariantach.

---

## 2. Diagnoza: dlaczego właściciel się gubi

Problemem **nie jest liczba podstron** (25 URL to mało). Problemem jest **liczba reprezentacji tej samej rzeczy** i liczba wejść do tego samego miejsca.

### 2.1 Te same 20 lokali występuje w 6 miejscach

1. Sekcja **Osiedle** - 6 kart budynków (metraż, "wolne: 2", cena od)
2. **Interaktywny plan osiedla** - klik w lokal
3. **Filtry + siatka kart** (budynki / typ / status / 4 sortowania, domyślnie 6 kart + "Pokaż wszystkie 20")
4. **Tabela Cennik** - 20 wierszy z tymi samymi danymi
5. **20 podstron lokali**
6. **CSV** z cenami

Ta sama cena 633 000 zł pojawia się na stronie głównej 5 razy. "Poddasze w cenie" - 6 razy. Dystans do Łodzi 32 km - 4 razy (Okolica, FAQ, /lokalizacja, każda podstrona lokalu).

### 2.2 Cztery równoległe wejścia w ofertę, zero hierarchii

Nagłówek: `Mieszkania i domy`, `Cennik`, `Sprawdź dostępność 13` oraz karty budynków w sekcji Osiedle - wszystkie prowadzą do tego samego zbioru danych, ale w innej formie. Użytkownik nie wie, która z nich jest "tą właściwą". To jest dokładnie to, co właściciel opisuje jako gubienie się.

### 2.3 Pętla bez wyjścia

`Strona główna → plan/filtry → podstrona lokalu → "Zobacz też" (kolejny lokal) → "Wszystkie mieszkania i domy" → ląduje w środku długiej strony głównej, filtry zresetowane → szukanie od nowa.`

Dodatkowo: `/mieszkania-i-domy` (bez ID) zwraca **404**, mimo że taki URL sam się prosi o listę. Kto obetnie adres, wypada ze strony.

### 2.4 Drobne błędy, które wzmacniają wrażenie chaosu

- "Zobacz też" na podstronie 2.2B pokazuje **1.1A i 1.1B, które są sprzedane**. Podpowiadamy klientowi rzeczy, których nie może kupić.
- Liczniki "0 z 16 mieszkań dostępnych / 0 z 4 domów / 0 budynków" renderują się jako **zera** przed hydratacją JS. Pierwsza klatka mówi "nic nie ma".
- Filtr budynków dubluje interaktywny plan (to samo zadanie, dwa różne interfejsy obok siebie).
- 4 opcje sortowania przy 20 rekordach to overkill.
- Nawigacja 7 pozycji na podstronie lokalu prowadzi w całości na stronę główną - z podstrony nie da się iść "w głąb", tylko "z powrotem".

### 2.5 Powtórzenia treściowe (to samo, innymi słowami)

| Treść | Ile razy |
|---|---|
| Poddasze w cenie, poza metrażem | 6 (hero, Osiedle, Standard, FAQ, podstrona, "Co warto wiedzieć") |
| Okolica / zalew / las / Wake Park | 4 (sekcja Okolica, FAQ, /lokalizacja, blok na każdej podstronie) |
| Dystanse Łódź/Stryków/Warszawa | 4 |
| 16 mieszkań i 4 domy | 9 na samej stronie głównej |
| Standard (pompa, podłogówka, okna) | 4 |
| Dane rejestrowe KRS/NIP/REGON | 3 (sekcja Deweloper, stopka, FAQ) |
| Proces zakupu | 2 (sekcja Deweloper + FAQ, praktycznie 1:1 ten sam tekst) |

### 2.6 Ryzyko SEO, o którym warto wiedzieć

20 podstron lokali ma niemal identyczny blok opisowy (te same akapity o Strykowie, lesie i pompie ciepła, zmieniają się tylko liczby). To klasyczny thin/duplicate content. Wycięcie tego bloku **poprawi** SEO, nie pogorszy. Podstron nie kasujemy - są wartościowe pod long tail i pod linkowanie z ogłoszeń.

---

## 3. Decyzje: co wycinamy, co scalamy, co zostaje

### WYCIĄĆ (bez zamiany)

| Element | Dlaczego |
|---|---|
| Karty 6 budynków w sekcji Osiedle | Dublet interaktywnego planu i filtra budynków |
| Filtr "Budynki" (7 chipów) | To samo robi plan, jednym kliknięciem |
| Sortowanie 4-opcjowe | Przy 20 rekordach wystarczy cena rosnąco + metraż |
| Przycisk "Pokaż wszystkie 20" | Pokazujemy od razu wszystkie, to nie sklep z tysiącem SKU |
| Sekcja "Życie / Nad wodą na co dzień" | 3 kafelki powtarzające hero i Okolicę |
| Blok "O mieszkaniu X" na 20 podstronach | Generyczny tekst SEO, duplikat, nic nie wnosi kupującemu |
| Mapa i sekcja lokalizacji na podstronie lokalu | Jest /lokalizacja, jeden link wystarczy |
| Dane rejestrowe w sekcji Deweloper | Zostają w stopce, tam jest ich miejsce |
| 5 z 11 pytań FAQ | Dublują sekcje, które użytkownik właśnie przewinął |
| 4 kafelki Standardu (materiały premium, prywatne wejście, rekuperacja, fotowoltaika jako osobne kafle) | Do scalenia w jedną linijkę "opcje za dopłatą" |

### SCALIĆ

| Z | Do |
|---|---|
| Osiedle (karty) + Mieszkania i domy (plan + filtry + karty) + Cennik (tabela) | **Jedna sekcja "Mieszkania i domy"**: plan interaktywny + jedna lista (tabela na desktop, karty na mobile) + 2 filtry (typ: mieszkania/domy/wszystkie, status: tylko dostępne on/off) |
| Sekcja Deweloper + Jak przebiega zakup | Jeden blok "Deweloper i zakup": 2 zdania + 3 kroki + partnerzy + rabat CBG |
| Okolica (HP) + /lokalizacja | Na HP: mapa 3D + 3 zdania + 4 dystanse + link. Pełna lista atrakcji i opisy tylko na /lokalizacja |

### ZOSTAJE bez zmian

Hero, Spacer 360 (2 przyciski, lazy load, dobrze zrobione), sekcja Standard po odchudzeniu, formularz kontaktowy z prefillem `?lokal=`, 20 podstron lokali (odchudzonych), /lokalizacja, CSV, strony prawne, cała warstwa wizualna.

---

## 4. Architektura docelowa

```
/                            Strona główna (8 sekcji, ok. 1 300 słów)
  hero
  mieszkania-i-domy          <- plan + JEDNA lista (jedyne źródło prawdy o ofercie)
  spacer                     <- 360
  standard                   <- 1 akapit + 6 kafelków + linijka "za dopłatą"
  okolica                    <- mapa + 3 zdania + 4 dystanse + link do /lokalizacja
  deweloper                  <- 2 zdania + 3 kroki zakupu + partnerzy + rabat
  faq                        <- 6 pytań
  kontakt

/mieszkania-i-domy/{id}      20 podstron, ok. 45% krótszych
/lokalizacja                 jedyne pełne miejsce o okolicy
/mieszkania-i-domy           301 -> /#mieszkania-i-domy (dziś 404)
/ceny-ofertowe.csv           bez zmian
strony prawne                bez zmian
```

**Nawigacja: 7 pozycji → 4**
`Mieszkania i domy` · `Standard` · `Okolica` · `Kontakt` + telefon + jeden CTA "Sprawdź dostępność (13)".

**Jedna ścieżka zamiast czterech:**
`Hero → Mieszkania i domy (plan lub lista) → podstrona lokalu → Zapytaj (formularz z prefillem)`
Wszystko inne (Standard, Okolica, Deweloper, FAQ) to materiał wspierający pod tą ścieżką, nie alternatywne trasy.

---

## 5. Efekt liczbowy (cel)

| metryka | teraz | po |
|---|---|---|
| sekcje na HP | 11 | 8 |
| słowa na HP | 2 769 | ~1 300 |
| kontrolki na HP | 96 | ~35 |
| reprezentacje oferty | 6 | 2 (plan + lista) + podstrony |
| pozycje w nawigacji | 7 | 4 |
| tekst podstrony lokalu | ~4 500 zn. | ~2 400 zn. |
| JS (transfer) | 715 KB | cel < 450 KB |
| hero | 448 KB | cel < 180 KB (AVIF, q65) |

---

## 6. Techniczne do poprawy przy okazji

1. **Liczniki dostępności liczone po stronie serwera** - koniec z "0 z 16" w pierwszej klatce.
2. **`/mieszkania-i-domy` → 301** na `/#mieszkania-i-domy`.
3. **"Zobacz też" tylko lokale dostępne**, dobierane po zbliżonej cenie/metrażu, nie po kolejności ID.
4. **Hero**: AVIF + q65 + `priority` + poprawne `sizes`, docelowo poniżej 180 KB.
5. **Schema.org**: po cięciu FAQ zaktualizować `FAQPage`, żeby nie zostało 11 pytań w danych strukturalnych przy 6 na stronie.
6. **`scroll-margin-top`** na kotwicach, żeby powrót z podstrony lądował na nagłówku sekcji, nie pod headerem.
7. Po cięciach ponownie zmierzyć JS i liczbę wariantów obrazów.

---

## 7. Czego NIE ruszamy

- Żadnych danych liczbowych: ceny, metraże, ogrody, statusy, dane rejestrowe, adresy, telefon, mail. Wszystko zostaje co do znaku.
- Warstwy wizualnej: kolory, typografia, układ kart, zdjęcia, render. Audyt dotyczy ilości i struktury, nie estetyki.
- Formularza i prefillu `?lokal=` - to działa i konwertuje.
- 20 podstron lokali jako URL-i. Odchudzamy treść, nie kasujemy adresów.
- Sitemap poza ewentualnym dodaniem redirectu.
