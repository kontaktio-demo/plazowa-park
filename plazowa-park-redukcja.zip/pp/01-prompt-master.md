# Prompt master - wklej raz na starcie sesji Claude Code

> Wklej to jako pierwszą wiadomość w repo plazowa-park. Potem lecisz etapami z katalogu `prompts/`, jeden etap = jedna wiadomość = jeden commit.

---

Pracujemy nad stroną Plażowa Park (Next.js App Router, produkcja: plazowa-park.pl). Strona jest skończona i wdrożona, wygląda dobrze i nie zmieniamy warstwy wizualnej. Problem jest inny: **jest jej za dużo**. Inwestor mówi, że gubi się na własnej stronie.

## Diagnoza

Te same 20 lokali (16 mieszkań + 4 domy) występuje dziś w sześciu reprezentacjach: karty budynków w sekcji Osiedle, interaktywny plan, filtry plus siatka kart, tabela Cennik, 20 podstron, plik CSV. Do tego cztery równoległe wejścia w ofertę w nawigacji i brak jasnej ścieżki powrotu z podstrony lokalu.

Strona główna: 11 sekcji, 2769 słów, 96 kontrolek, 83 linki. Cel: 8 sekcji, ok. 1300 słów, ok. 35 kontrolek.

## Cel przebudowy

Jedna ścieżka zamiast czterech:

```
Hero -> Mieszkania i domy (plan + JEDNA lista) -> podstrona lokalu -> formularz z prefillem
```

Wszystko inne (Standard, Okolica, Deweloper, FAQ) to materiał wspierający, nie alternatywne trasy.

## Zasady twarde (obowiązują w każdym etapie)

1. **Zero zmian w danych.** Ceny, metraże, powierzchnie ogrodów, statusy, liczba pokoi, dane rejestrowe, adresy, telefon, mail, treści prawne zostają co do znaku. Jeśli coś usuwamy, to tylko dlatego, że ta sama informacja zostaje w innym miejscu na stronie.
2. **Zero zmian wizualnych.** Nie ruszamy palety, typografii, komponentów UI, zdjęć, renderów, animacji. Usuwamy elementy albo je scalamy, nie przeprojektowujemy.
3. **Nie kasujemy URL-i.** Wszystkie 25 adresów zostaje w sitemapie. Jedyna zmiana w routingu to dodanie redirectu 301 dla `/mieszkania-i-domy` (dziś 404).
4. **Metadane zostają.** Title, description, OG, geo, schema.org zostają, z jednym wyjątkiem: jeśli tniemy pytania FAQ, aktualizujemy też `FAQPage`, żeby dane strukturalne zgadzały się z treścią.
5. **Jeden etap = jeden commit** z opisem w formacie `refactor(plazowa): etap N - <co>`. Nie łączymy etapów.
6. **Po każdym etapie:** `npm run build` musi przejść, zero błędów TypeScript, zero martwych importów i nieużywanych komponentów (usunięte komponenty kasujemy z repo, nie zostawiamy zakomentowanych).
7. **Nie pytaj o zgodę na rzeczy opisane w etapie.** Zakres jest zamknięty. Jeśli natrafisz na coś spoza zakresu, zanotuj w `NOTATKI-REFACTOR.md` i jedź dalej.
8. **Przed usunięciem komponentu sprawdź, czy nie jest używany gdzie indziej** (podstrony lokali dzielą część komponentów ze stroną główną).

## Zanim zaczniesz

Wykonaj inwentaryzację i wypisz mi:
- ścieżki plików wszystkich sekcji strony głównej wraz z ich `id`
- komponenty współdzielone między stroną główną a podstronami lokali
- gdzie leży źródło danych o lokalach (JSON / TS / CMS) i czy liczniki dostępności są liczone na serwerze czy na kliencie
- gdzie generowany jest opisowy blok tekstu na podstronach lokali

Nic jeszcze nie zmieniaj. Czekaj na prompt Etapu 1.
