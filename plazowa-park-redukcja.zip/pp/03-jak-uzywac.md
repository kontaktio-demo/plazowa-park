# Jak używać tej paczki

## Kolejność

1. Przeczytaj `00-audyt.md` - tu są liczby i uzasadnienia. Jeśli z czymś się nie zgadzasz, zmień to **przed** startem, bo etapy są od tego zależne.
2. Otwórz repo plazowa-park w Claude Code.
3. Wklej `01-prompt-master.md` jako pierwszą wiadomość. Dostaniesz inwentaryzację plików i komponentów. Sprawdź ją.
4. Potem etapami, jeden na wiadomość, w kolejności:
   - `prompts/etap-1-nawigacja.md`
   - `prompts/etap-2-oferta.md` (najważniejszy, tu znika większość problemu)
   - `prompts/etap-3-tresc-hp.md`
   - `prompts/etap-4-podstrony.md`
   - `prompts/etap-5-techniczne.md`
   - `prompts/etap-6-qa.md`
5. Po każdym etapie: preview na Vercelu, szybkie klikniecie, dopiero potem następny.
6. `02-mapa-tresci.md` trzymaj otwarte - to kontrola, że nic nie zniknęło bez zamiennika.

## Gdzie można przystanąć

Po etapie 2 strona jest już zauważalnie prostsza. Etapy 3-4 dokładają redukcję treści, 5-6 to porządki. Jeśli brakuje czasu, minimum to etapy 1-2.

## Co pokazać inwestorowi

Po etapie 2, z jednym zdaniem: "dostępność mieszkań i domów jest teraz w jednym miejscu, plan i lista, nic więcej". Jeśli dalej będzie mówił, że się gubi, problem leży gdzie indziej i warto go przeprowadzić przez stronę na żywo i zobaczyć, gdzie klika.
