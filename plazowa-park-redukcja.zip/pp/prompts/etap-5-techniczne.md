# Etap 5 - warstwa techniczna

## Do zrobienia

1. **Liczniki dostępności liczone na serwerze.** Dziś w HTML-u przed hydratacją jest `0 z 16 mieszkań dostępnych`, `0 z 4 domów`, `0 budynków`. Policz je z danych w czasie renderu, klient ma tylko aktualizować po filtrowaniu. Sprawdź `curl -s https://... | grep` albo View Source.
2. **Hero:** dziś `hero.webp` w wariancie 2400px waży 448 KB. Wygeneruj AVIF, zejdź z jakością do 65, ustaw poprawne `sizes` i `priority`. Cel poniżej 180 KB dla największego wariantu.
3. **JS:** teraz 715 KB transferu w 10 plikach. Po usunięciu filtrów budynków, sortowań i kart budynków zmierz ponownie i podaj wynik. Sprawdź, czy da się zejść poniżej 450 KB (kandydaci: biblioteka do interaktywnego planu, komponenty spaceru 360 ładowane tylko po kliknięciu, ewentualne dublujące się importy ikon).
4. **Obrazy:** dziś strona główna generuje 162 unikalne warianty `next/image`. Po cięciach zmierz ponownie, ogranicz zbyt gęstą listę `deviceSizes`/`imageSizes` w `next.config`, jeśli to ona mnoży warianty.
5. **Schema.org:** `FAQPage` zgodny z 6 pytaniami po etapie 3. Sprawdź też `Residence`/`Offer`/`Product` jeśli są, żeby ceny zgadzały się po zmianach w sekcji oferty.
6. **Sitemap:** bez zmian (25 URL), zweryfikuj tylko, że `lastmod` się aktualizuje i że nowy redirect nie trafił do sitemapy.
7. **Sprawdź konsolę** na stronie głównej i jednej podstronie lokalu: zero błędów i warningów Reacta po zmianach.

## Definicja gotowości

- w źródle HTML widać `13` a nie `0` w liczniku dostępnych
- podaj mi tabelę przed/po: JS transfer, waga hero, liczba wariantów next/image, LCP z lokalnego `next build && next start` albo z Lighthouse
- `npm run build` przechodzi
- commit: `refactor(plazowa): etap 5 - wydajność i dane strukturalne`
