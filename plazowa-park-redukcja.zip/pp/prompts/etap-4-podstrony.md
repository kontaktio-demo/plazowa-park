# Etap 4 - odchudzenie podstron lokali

Dotyczy wszystkich 20 podstron `/mieszkania-i-domy/{id}`. URL-e zostają, treść się skraca o ok. 45%.

## Do zrobienia

1. **Usuń blok opisowy "O mieszkaniu/domu X"** (4 akapity generowane z szablonu: o kameralnej skali, o dystansie do Łodzi i Strykowa, o cenie za m² i energooszczędności, o rozkładzie i elewacji). To duplikat treści powielony w 20 wariantach i szkodzi SEO zamiast pomagać.
2. **Usuń akapit podsumowujący** pod parametrami (`82,05 m², 4 pokoje i własny ogród... tak w skrócie prezentuje się...`) - te same liczby są w tabeli parametrów tuż obok.
3. **Usuń sekcję `Lokalizacja osiedla i dojazd` z mapą.** Zamiast niej jedna linijka z linkiem: `Osiedle leży przy ul. Plażowej 5 i 7 w Głownie. Zobacz lokalizację i dojazd ->` prowadząca na `/lokalizacja`.
4. **Zostaje bez zmian:** breadcrumb, wizualizacja, plan zagospodarowania z zaznaczonym lokalem, blok ceny i parametrów, rzuty obu kondygnacji z wykazem pomieszczeń, blok `Co jeszcze warto wiedzieć` (poddasze / miejsca postojowe / liczba pokoi - to realny konkret, którego nie ma nigdzie indziej), PDF z rzutem, CTA `Zapytaj o to mieszkanie` z prefillem `?lokal=`.
5. **Napraw `Zobacz też`:**
   - pokazuj wyłącznie lokale ze statusem `W sprzedaży` (dziś proponuje sprzedane 1.1A i 1.1B)
   - dobieraj 3 najbliższe ceną, nie po kolejności ID
   - jeśli oglądany lokal jest sprzedany albo zarezerwowany, dopisz nad listą: `Ten lokal jest niedostępny. Zobacz dostępne o podobnym metrażu:`
6. **Meta description podstron** zostaw bez zmian, ale sprawdź, czy nie cytuje usuniętych akapitów.
7. Jeśli sprzedany lokal ma stronę, zostaw ją (SEO), ale CTA zamień na `Zapytaj o podobne` z prefillem typu lokalu zamiast numeru.

## Definicja gotowości

- tekst podstrony (bez nagłówka i stopki) mieści się w 2000-2600 znakach
- `Zobacz też` na żadnej podstronie nie pokazuje lokalu sprzedanego
- `npm run build` przechodzi, wszystkie 20 ścieżek się generuje
- commit: `refactor(plazowa): etap 4 - odchudzenie podstron lokali`
