# Etap 1 - nawigacja i wejścia

Zakres: header, mobilne menu, sticky bar, stopka, routing. Nie ruszamy jeszcze sekcji.

## Do zrobienia

1. **Nawigacja główna z 7 pozycji na 4:**
   - zostają: `Mieszkania i domy` (#mieszkania-i-domy), `Standard` (#standard), `Okolica` (#okolica), `Kontakt` (#kontakt)
   - znikają: `Osiedle`, `Cennik`, `Spacer 360` (ich sekcje zostaną scalone lub są krótkie i widoczne przy scrollu)
2. **Jeden CTA w headerze:** `Sprawdź dostępność (13)` prowadzi do `#mieszkania-i-domy`. Licznik ma być liczony z danych, nie zahardkodowany. Obok zostaje numer telefonu.
3. **Menu mobilne:** te same 4 pozycje + telefon + CTA. Nic więcej.
4. **Sticky bar na dole (mobile):** zostaje w formie telefon + `Zapytaj o mieszkanie lub dom`. Na desktopie ukryty, bo dubluje header.
5. **Stopka - blok Nawigacja:** te same 4 pozycje co w headerze. Reszta stopki (kontakt, deweloper, dane rejestrowe, prawne) bez zmian.
6. **Routing:** dodaj redirect 301 `/mieszkania-i-domy` -> `/#mieszkania-i-domy` (dziś 404).
7. **Kotwice:** dodaj `scroll-margin-top` odpowiadający wysokości sticky headera na wszystkich sekcjach z `id`, żeby powrót z podstrony lądował na nagłówku sekcji, a nie pod headerem.
8. Na podstronach lokali nawigacja ma być identyczna (te same 4 pozycje z prefiksem `/`).

## Definicja gotowości

- header, menu mobilne i stopka mają dokładnie te same 4 pozycje
- `/mieszkania-i-domy` zwraca 301, nie 404
- kliknięcie `Mieszkania i domy` z podstrony lokalu ląduje na nagłówku sekcji, nie w połowie tabeli
- `npm run build` przechodzi
- commit: `refactor(plazowa): etap 1 - redukcja nawigacji i redirect listy`
