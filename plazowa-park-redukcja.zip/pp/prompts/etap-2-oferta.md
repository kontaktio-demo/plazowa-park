# Etap 2 - scalenie oferty w jedno źródło prawdy

Najważniejszy etap. Tu znika większość chaosu.

## Stan obecny

Trzy osobne sekcje pokazują te same 20 lokali:
- `#osiedle` - 6 kart budynków (zdjęcie, liczba lokali, metraże, "wolne: X", cena od)
- `#mieszkania-i-domy` - interaktywny plan + filtr budynków (7 chipów) + filtr typu + 4 sortowania + siatka 6 kart + przycisk "Pokaż wszystkie 20"
- `#cennik` - tabela 20 wierszy z tymi samymi danymi

## Do zrobienia

1. **Usuń sekcję `#osiedle` w całości** razem z komponentem kart budynków i zdjęciami budynków użytymi tylko tam (pliki graficzne zostają w repo, usuwamy tylko render). Akapit wprowadzający z tej sekcji ("Osiedle to 16 mieszkań i 4 domy w 10 budynkach...") przenieś jako lead do sekcji `#mieszkania-i-domy`, skrócony do dwóch zdań.
2. **Usuń sekcję `#cennik` jako osobną sekcję.** Tabela przenosi się do `#mieszkania-i-domy` jako jedyna lista.
3. **Przebuduj `#mieszkania-i-domy` do układu:**
   - lead: 2 zdania (z punktu 1)
   - interaktywny plan osiedla (zostaje bez zmian funkcjonalnych)
   - pasek statystyk: `13 dostępnych` / `20 wszystkich` / `od 633 000 zł` - **liczone po stronie serwera**, nigdy nie renderowane jako zera
   - dwa filtry i nic więcej: `Typ: Wszystkie / Mieszkania (16) / Domy (4)` oraz przełącznik `Tylko dostępne`
   - jedna lista: na desktopie tabela (jak obecna z sekcji Cennik, wszystkie 20 wierszy, bez paginacji), na mobile karty
   - sortowanie: tylko `Cena rosnąco` (domyślnie) i `Metraż malejąco`
   - pod listą: link do `ceny-ofertowe.csv` i nota o cenach brutto (jak obecnie)
4. **Usuń:** filtr budynków (7 chipów), pozostałe 2 opcje sortowania, przycisk "Pokaż wszystkie 20", siatkę kart na desktopie.
5. **Klik w lokal na planie** ma scrollować do jego wiersza w tabeli i go podświetlić, a nie otwierać osobny widok. Klik w wiersz albo w nazwę lokalu prowadzi na podstronę lokalu.
6. Usuń z repo komponenty, które po tym etapie nie są nigdzie używane.

## Definicja gotowości

- na całej stronie głównej dane o lokalach występują dokładnie w dwóch miejscach: plan i jedna lista
- liczniki pokazują poprawne wartości w HTML-u przed uruchomieniem JS (sprawdź `curl` albo View Source)
- zero przycisków sortowania i filtrowania poza wymienionymi
- `npm run build` przechodzi
- commit: `refactor(plazowa): etap 2 - jedna sekcja oferty zamiast trzech`
