# Etap 6 - QA i raport końcowy

## Do zrobienia

1. Przejdź ścieżkę użytkownika na desktopie i mobile:
   `wejście -> hero -> Sprawdź dostępność -> plan -> klik w lokal -> tabela podświetla wiersz -> wejście na podstronę -> Zapytaj o to mieszkanie -> formularz z wypełnionym polem lokalu`
2. Sprawdź powrót: z podstrony lokalu `Wszystkie mieszkania i domy` -> ląduje na nagłówku sekcji, widać plan i listę.
3. Sprawdź, że każda informacja z listy w `NOTATKI-REFACTOR.md` (usunięte -> gdzie zostaje) faktycznie jest na stronie.
4. Sprawdź wszystkie linki wewnętrzne (zero 404, zero martwych kotwic).
5. Sprawdź, że dane lokali (ceny, metraże, statusy) są identyczne jak przed refactorem - porównaj z `ceny-ofertowe.csv`.
6. Sprawdź formularz: wysyłka, walidacja, zgoda RODO, prefill `?lokal=`.
7. Sprawdź stronę na szerokości 360, 768, 1440.

## Raport końcowy - podaj mi tabelę

| metryka | przed | po |
|---|---|---|
| sekcje na stronie głównej | 11 | |
| słowa na stronie głównej | 2769 | |
| przyciski/kontrolki na stronie głównej | 96 | |
| linki na stronie głównej | 83 | |
| znaki tekstu na podstronie lokalu | ~4500 | |
| JS transfer | 715 KB | |
| największy wariant hero | 448 KB | |
| warianty next/image na stronie głównej | 162 | |

Plus lista rzeczy, które zapisałeś w `NOTATKI-REFACTOR.md` jako wykryte poza zakresem.

commit: `refactor(plazowa): etap 6 - QA i raport`
