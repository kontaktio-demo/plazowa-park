# Etap 3 - odchudzenie sekcji treściowych strony głównej

Cel: z 2769 słów zejść do ok. 1300, nie tracąc żadnej informacji, która nie występuje gdzie indziej.

## Do zrobienia

1. **Sekcja `#zycie` ("Nad wodą na co dzień") - usuń w całości.** Trzy kafelki (Kameralne osiedle / Las i woda za progiem / Przestrzeń dla dzieci) powtarzają hero i sekcję Okolica. Zdjęcie z tej sekcji przenieś jako tło albo obraz wiodący sekcji `#okolica`, jeśli pasuje kompozycyjnie. Jeśli nie pasuje, zostaw sekcję Okolica bez zmian graficznych.

2. **Sekcja `#standard`:**
   - trzy akapity opisowe tnij do jednego (maks. 60 słów): technologia energooszczędna, pompa ciepła i podłogówka w standardzie, poddasze w cenie i poza metrażem
   - kafelki z 10 na 6: `Pompa ciepła`, `Ogrzewanie podłogowe`, `Panoramiczne okna`, `Prywatny ogród i taras`, `2 miejsca postojowe (domy z garażem)`, `Poddasze w cenie`
   - usuwane kafelki (`Rekuperacja`, `Fotowoltaika`, `Wykończenie pod klucz`, `Materiały premium`, `Prywatne wejście`) zastąp jedną linijką pod siatką: `Za dopłatą, na etapie budowy: rekuperacja, fotowoltaika, wykończenie pod klucz.` plus krótka wzmianka o elewacji (elastyczna cegła, tynk, blacha na rąbek) i prywatnym wejściu w akapicie wiodącym
   - zdanie o prospekcie informacyjnym zostaje

3. **Sekcja `#okolica` - skróć do:**
   - nagłówek i jeden akapit (maks. 50 słów)
   - mapa 3D okolicy z hotspotami (zostaje) albo przełącznik mapy satelitarnej - **zostaw tylko jedno z dwóch**, domyślnie mapę 3D z hotspotami
   - cztery dystanse (Łódź / Stryków / stacja kolejowa / Warszawa) - zostają
   - link `Lokalizacja i dojazd` -> `/lokalizacja`
   - **usuń listę 6 atrakcji** (Zalew, Wake Park, las, ścieżki, wydmy, zaplecze) ze strony głównej. Ta lista w identycznej formie jest na `/lokalizacja` i tam zostaje.

4. **Sekcja `#deweloper`:**
   - zostają 2 zdania o KS Prestige Development i dwa kafelki
   - **usuń blok "Dane rejestrowe"** (KRS, NIP, REGON, status VAT, kapitał zakładowy) - komplet tych danych jest w stopce
   - `Jak przebiega zakup`: z 5 kroków zrób 3: `Wybór i oględziny` / `Umowa rezerwacyjna` / `Umowa deweloperska i przeniesienie własności`. Zdanie o rachunku powierniczym i prospekcie zostaje pod spodem
   - Partnerzy inwestycji i rabat 10% CBG - bez zmian

5. **Sekcja `#faq` - z 11 pytań na 6.** Zostają:
   - Czy poddasze jest wliczone w cenę?
   - Jakie są ceny i czy są dostępne mieszkania i domy?
   - Czy do mieszkania albo domu należy ogród i miejsce postojowe?
   - Jak wygląda proces zakupu?
   - Czy nabywcy mają zniżki u partnerów inwestycji?
   - Kto jest deweloperem inwestycji?

   Usuwane (bo dublują sekcje, które użytkownik właśnie przewinął): `Ile mieszkań i domów liczy osiedle`, `Gdzie dokładnie leży osiedle`, `Jak daleko jest do Łodzi, Strykowa i Warszawy`, `Co znajduje się w okolicy osiedla`, `Jaki jest standard wykończenia i technologia`.

   **Zaktualizuj schema.org `FAQPage`**, żeby zawierał dokładnie te 6 pytań.

## Definicja gotowości

- strona główna ma 8 sekcji: hero, mieszkania-i-domy, spacer, standard, okolica, deweloper, faq, kontakt
- licznik słów w treści strony głównej mieści się w przedziale 1200-1500 (podaj mi zmierzoną wartość)
- żadna usunięta informacja nie zniknęła ze strony bez zamiennika (dopisz w `NOTATKI-REFACTOR.md` tabelę: usunięte zdanie -> gdzie ta sama informacja zostaje)
- `npm run build` przechodzi
- commit: `refactor(plazowa): etap 3 - redukcja treści strony głównej`
